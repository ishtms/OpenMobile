//
//  GADDebugOptionsViewController.h
//  Google Mobile Ads SDK
//
//  Copyright 2016 Google LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class GADDebugOptionsViewController;

/// Delegate for the GADDebugOptionsViewController.
NS_SWIFT_NAME(DebugOptionsViewControllerDelegate)
@protocol GADDebugOptionsViewControllerDelegate <NSObject>

/// Called when the debug options flow is finished.
- (void)debugOptionsViewControllerDidDismiss:(nonnull GADDebugOptionsViewController *)controller
    NS_SWIFT_UI_ACTOR;

@end

/// Displays debug options to the user.
NS_SWIFT_NAME(DebugOptionsViewController)
@interface GADDebugOptionsViewController : UIViewController

/// Creates and returns a GADDebugOptionsViewController object initialized with the ad unit ID.
/// @param adUnitID An ad unit ID for the Google Ad Manager account that is being configured with
/// debug options.
+ (nonnull instancetype)debugOptionsViewControllerWithAdUnitID:(nonnull NSString *)adUnitID;

/// Delegate for the debug options view controller.
@property(nonatomic, weak, nullable) IBOutlet id<GADDebugOptionsViewControllerDelegate> delegate;

@end
